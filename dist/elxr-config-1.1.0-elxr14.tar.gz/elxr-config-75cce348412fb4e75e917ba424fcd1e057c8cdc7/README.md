# elxr-config

## Deprecation Notice

Image manifests which include _ultra-minimal_ in the pathname should now
be accessed using _minimal_.  For example the path

```bash
elxr/aria/vm/ultra-minimal/image.yaml
```

should now be

```bash
elxr/aria/vm/minimal/image.yaml
```

Currently, both paths work, but the _ultra-minimal_ one will be removed
in a future release.

## Introduction

This project provides stock configuration manifests for building Linux images
using Rucksack and Tiler tools. With these manifests you can create the
following image types:

* Base images - standard root filesystems
* VM images - ex. installer, minimal, AI
* Cloud images - ex. Azure, EC2
* Board specific images - ex. Orin, IMX
* Container images

## Manifest format

### Image manifest

The image manifest defines the name, description, architecture, version and so
on for an image. Each image manifest can be used for building an image.
Typically there are two image manifests in each directory, for example in
vm/minimal/:

* image-ostree.yaml: The ostree image
* image.yaml: The image without ostree

You can use the following command to find all the image manifests:

```bash
  $ find . -name 'image*.yaml'
```

And use Rucksack to build them:

```bash
  $ rs build --debug --config path/to/image-ostree.yaml
  $ ls *.img *.img.zst
```

Review the README.md in the Rucksack repository for more details on "rs build"

### Package manifest fragment

The package manifest fragment lists the packages which are to be installed to
the image. They are part of a "Image manifest", for example in
vm/xfce4/image-ostree.yaml we have:

  ```yaml
  packages:
    - ${include:manifests/packages-ostree.yaml}
    - ${include:manifests/packages-xfce4.yaml}
  ```

Which means that packages in manifests/packages-ostree.yaml and
manifests/packages-xfce4.yaml will be installed in the resulting image.

## Create your own manifest

1. Copy minimal directory as a start point

   ```bash
     $ cp -a vm/minimal my-image
   ```

   You can use other preferred names to replace my-image.
1. Customize my-image
   There are two image manifests in my-image directory:
   * image-ostree.yaml: The ostree image
   * image.yaml: The image without ostree

   The two manifests are independent, you can keep the one you need, and remove
   the other one. Here we use image-ostree.yaml as an example. Open
   image-ostree.yaml and edit it as needed. For example, edit name, description,
   architecture and version, and also edit the "packages" section to include
   more packages, you can use manifest fragments from the manifests directory:

    ```yaml
      packages:
      - ${include:manifests/packages-ostree.yaml}
      - ${include:manifests/packages-xfce4.yaml}
    ```

   Or add the packages directly:

    ```yaml
      packages:
      - ${include:manifests/packages-ostree.yaml}
      - task-xfce-desktop
      - network-manager-gnome
    ```

1. Build Customized image

   ```bash
    $ rs build --debug --config path/to/my-image/image-ostree.yaml
   ```

   Review the README.md in the Rucksack repository for more details on
   "rs build"

## Development

You may wish to develop and submit changes to this project. This can be done
following these steps:

1. Fork the repository into your GitLab namespace
1. Create a feature branch (for example: `feature/amazing-feature`)
1. Commit your changes
1. Push to the branch
1. Open a GitLab merge request

Be sure to follow our contribution guidelines and branch guidelines outlined
below.

### Contributing

Contributions are welcome! Please ensure:

* Changes and additions align with existing filenames and content
* Changes have been tested and are working at the time of submission
* Changes include documentation updates when applicable
* Commit messages are descriptive

### Branch Guidelines

* Send changes to the `main` branch **unless** it is a bug fix that only applies
  to a specific release branch
* Merge requests to port bug fixes from `main` to release branches should be
  sent after a bug fix is merged to `main`
* Minor releases should only include bug fixes
* Major releases will include bug fixes and new features
