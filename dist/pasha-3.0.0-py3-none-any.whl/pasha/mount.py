"""
Copyright (c) 2024-2025 Wind River Systems, Inc.

SPDX-License-Identifier: Apache-2.0

"""

import contextlib
import logging
import os
import stat
import subprocess

from pasha.log import complete_step, die


def _dm_major():
    """Major number the kernel assigned to device-mapper, or None."""
    try:
        with open("/proc/devices", encoding="utf-8") as f:
            for line in f:
                fields = line.split()
                if len(fields) == 2 and fields[1] == "device-mapper":
                    return int(fields[0])
    except (OSError, ValueError):
        pass
    return None


def _is_device_mapper(path):
    """True when path is (or points at) a device-mapper node.

    The prefix checks alone are not enough. LVM is driven here with
    'udev_rules = 0' (there is no udev daemon in the build container), so
    libdevmapper creates /dev/mapper/<vg>-<lv> as a real block node instead
    of the symlink into /dev/dm-* that udev would have made. realpath() of
    the /dev/<vg>/<lv> symlink therefore stops at /dev/mapper/<vg>-<lv> and
    never reaches a /dev/dm-* name, so a genuine logical volume looks like
    an ordinary file here.

    Getting this wrong is expensive: mount_disk falls through to the
    systemd-dissect branch, and 'systemd-dissect --umount' detaches the loop
    device backing the volume group. That destroys the physical volume while
    the logical volumes are still mapped, so the next stage fails with
    'Volume group "<vg>" not found' and the loop device is left unbound but
    still carrying partition children, which makes it unusable for later
    builds.

    So fall back to the device-mapper major number, which is true of every
    dm node however its /dev entry was created.
    """
    target = path
    try:
        target = os.path.realpath(path)
    except OSError:
        pass
    if target.startswith("/dev/mapper/") or target.startswith("/dev/dm-"):
        return True

    major = _dm_major()
    if major is None:
        return False
    try:
        st = os.stat(path)
    except OSError:
        return False
    return stat.S_ISBLK(st.st_mode) and os.major(st.st_rdev) == major


@contextlib.contextmanager
def mount_disk(disk, rootfs):
    """Mount and unmount a disk.

    :params disk: string, block device to mount.
    :params rootfs; string, path to mount the block
                    device.
    """
    if disk is None:
        yield None
        return

    disk_str = str(disk)
    rootfs_str = str(rootfs)

    # SiMa.ai: a logical volume holds a bare file system, with no partition
    # table for systemd-dissect to find, so mount it directly. Covers both
    # /dev/mapper/<vg>-<lv> and the /dev/<vg>/<lv> symlink LVM also creates.
    if _is_device_mapper(disk_str):
        logging.debug(f"Mounting device-mapper volume {disk_str} on {rootfs_str}.")
        subprocess.run(["mkdir", "-p", rootfs_str], check=True)
        subprocess.run(["mount", disk_str, rootfs_str], check=True)
        try:
            yield
        finally:
            logging.debug(f"Unmounting {rootfs_str}...")
            subprocess.run(["umount", rootfs_str], check=False)
        return

    # If internal modules (like unpack.py or bootloader.py)
    # pass a partition path (e.g., /dev/loop26p4), systemd-dissect will reject it.
    # We intercept it here and mount via a resilient userspace loop offset.
    if "loop" in disk_str and "p" in disk_str:
        logging.debug(f"Intercepted partition node {disk_str} in mount_disk. Using offset fallback...")
        # Only the mount setup may fall back to systemd-dissect; the yield
        # must stay outside this try so exceptions raised by the caller's
        # body propagate instead of triggering a second yield.
        mounted = False
        try:
            base_loop, part_num = disk_str.rsplit("p", 1)

            # Query parted for exact byte configurations of the parent disk
            cmd = ["parted", "-m", base_loop, "unit", "B", "print"]
            res = subprocess.run(cmd, capture_output=True, text=True, check=True)

            offset = None
            size = None
            for line in res.stdout.splitlines():
                if line.startswith(f"{part_num}:"):
                    parts = line.split(":")
                    # parted layout: number:start:end:size:...
                    offset = parts[1].rstrip("B")
                    size = parts[3].rstrip("B")
                    break

            if offset and size:
                logging.debug(f"Mounting via offset: {base_loop} (offset={offset}, size={size})")
                subprocess.run(["mkdir", "-p", rootfs_str], check=True)
                mount_opts = f"loop,offset={offset},sizelimit={size}"
                subprocess.run(["mount", "-o", mount_opts, base_loop, rootfs_str], check=True)
                mounted = True
            else:
                logging.warning(f"Partition {part_num} layout not found in parted. Swapping to systemd-dissect.")
        except Exception as e:
            logging.warning(f"Offset mount setup failed: {e}. Swapping to systemd-dissect.")

        if mounted:
            try:
                yield
            finally:
                logging.debug(f"Unmounting offset image from {rootfs_str}...")
                subprocess.run(["umount", rootfs_str], check=False)
            return

    # Original systemd-dissect logic for whole disks
    logging.debug(f"Mounting whole disk image via systemd-dissect: {disk_str}...")
    subprocess.run(
        ["systemd-dissect", "--mount", "--mkdir", disk_str, rootfs_str],
        capture_output=True,
        check=True,
    )

    try:
        yield
    finally:
        logging.debug("Unmounting image...")
        subprocess.run(
            ["systemd-dissect", "--umount", rootfs_str], capture_output=True, check=True
        )


@contextlib.contextmanager
def mount_partition(disk, fs, target):
    with complete_step(f"Mounting {disk} on {target}."):
        subprocess.run(["mount", "-t", fs, disk, target])
        try:
            yield
        finally:
            logging.debug(f"Unmounting {target}.")
            subprocess.run(["umount", target], check=False)


@contextlib.contextmanager
def bind_mounts(sources, dest_root):
    for src in sources:
        dst = dest_root.joinpath(src)
        logging.debug(f"Mounting /{src} on {dst}.")
        subprocess.run(["mount", "-o", "bind", f"/{src}", str(dst)], check=True)
    try:
        yield
    finally:
        for src in reversed(sources):
            dst = dest_root.joinpath(src)
            logging.debug(f"Unmounting {dst}.")
            subprocess.run(["umount", dst], check=False)
