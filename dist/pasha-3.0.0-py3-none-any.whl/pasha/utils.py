"""
Copyright (c) 2024-2025 Wind River Systems, Inc.

SPDX-License-Identifier: Apache-2.0

"""

import logging
import os
import re
import shutil
import subprocess
import sys
import atexit

from urllib.parse import urlparse

from pasha.log import complete_step, die

LOG = logging.getLogger(__name__)


def run_command(args, **kwargs):
    """Run a command in a shell."""
    LOG.debug("Running %s" % format_command(args))

    outputs = ""
    try:
        sp = subprocess.Popen(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            stdin=subprocess.PIPE,
            universal_newlines=True,
            **kwargs,
        )
    except FileNotFoundError:
        msg = f"You do not have {args[0]} installed."
        LOG.error(msg)
        sys.exit(1)
    except subprocess.CalledProcessError as e:
        args = format_command(args)
        msg = (
            f"Running the following command {args} resulted in a non-zero return code: "
        )
        msg += f"{e.returncode}"
        LOG.error(msg)
        LOG.error("'stdout': ")
        LOG.error(e.stdout)
        LOG.error("'stderr': ")
        LOG.error(e.stderr)
        sys.exit(1)
    except Exception as e:
        msg = f"Error running the following command {format_command(args)}: {e}"
        LOG.error(msg)
        sys.exit(1)

    while True:
        output = sp.stdout.readline()
        if output:
            LOG.debug(output.rstrip("\n"))
            outputs += output
        if sp.poll() is not None:
            break

    # Read the remaining logs from stdout after process terminates
    ret = sp.poll()
    output = sp.stdout.read()
    if output:
        LOG.debug(output.rstrip("\n"))
        outputs += output

    return ret, outputs.rstrip("\n")


class Chroot(object):
    """Run a command in a chrootable target."""

    def __init__(self, context, root):
        self.context = context
        self.root = root

        self.cmd = ["bwrap", "--bind", self.root, "/"]

        # vfs mounts
        self.cmd += ["--proc", "/proc"]
        self.cmd += ["--dev-bind", "/dev", "/dev"]
        self.cmd += ["--bind", "/sys", "/sys"]

        # fs mounts
        self.cmd += ["--dir", "/run"]

        # bwrap args
        self.cmd += ["--share-net"]
        self.cmd += ["--die-with-parent"]
        self.cmd += ["--chdir", "/"]

        # Debian policy is to start daemons by default. The policy-rc.d
        # script can be used to choose which ones to start.
        # Let's install one that disable all daemons by default.
        self.policyrcd = self.root.joinpath("usr/sbin/policy-rc.d")

    def __enter__(self):
        with complete_step("Setting up chroot target"):
            resolv = self.root.joinpath("etc/resolv.conf")
            if resolv.exists() or resolv.is_symlink():
                # Use the host's /etc/resolv.conf
                os.rename(resolv, self.root.joinpath("etc/resolv.conf.bak"))
                self.cmd += ["--bind", "/etc/resolv.conf", "/etc/resolv.conf"]

            # Disable all daemons when using the chroot.
            if self.policyrcd.exists():
                self.policyrcd.write_text("#!/bin/sh\nexit 101\n")

        return self

    def __exit__(self, exc_type, exc_value, traceback):
        with complete_step("Tearing down chroot target"):
            resolv = self.root.joinpath("etc/resolv.conf.bak")
            if resolv.exists() or resolv.is_symlink():
                os.rename(resolv, self.root.joinpath("etc/resolv.conf"))

            # Allow daemons to start by default.
            if self.policyrcd.exists():
                self.policyrcd.unlink()

    def run(self, args, **kwargs):
        """Run a command im a chrootable environment"""
        try:
            LOG.debug(f"Running {subprocess.list2cmdline(args)}.")
            return subprocess.run(self.cmd + args, check=True, **kwargs)
        except subprocess.CalledProcessError as e:
            die(f"Failed to run command: " + e.stderr.decode("utf-8").strip())


def fetch(source):
    """Fetch a file from a specific site."""
    a = urlparse(source)
    path = os.path.basename(a.path)

    LOG.info(f"Fetching from {source}.")
    run_command(["curl", source, "-o", path])
    return path


def which(cmd):
    return shutil.which(cmd)


def format_command(args):
    """Format command string for pretty printing."""
    if isinstance(args, list):
        return subprocess.list2cmdline(args)


# SiMa.ai: OmegaConf resolvers used by SiMa.ai package and image manifests.
from omegaconf import OmegaConf


def package_constructor(filename, params=None):
    """Resolve ${package:<file>[,<params>]} - load a manifest and merge params."""
    try:
        LOG.info(f"Loading package {filename}, parmas: {params}")
        if params:
            paramsconf = OmegaConf.create(params)
        else:
            paramsconf = OmegaConf.create()
        return OmegaConf.merge(paramsconf, OmegaConf.load(filename))
    except Exception as e:
        LOG.exception(f"Failed to read package file: {e}")
        sys.exit(1)


def clean_loop_device(device_name: str) -> None:
    """Detach a loop device, tolerating one that is already free.

    Registered with atexit, so it runs after the pipeline has finished and
    the device may already have been released, in which case losetup exits
    non-zero with ENXIO on stderr -- a line that lands after the last build
    step and reads like a failure. The kernel publishes the attachment state
    under /sys, so test that rather than matching on losetup's message, and
    keep reporting a genuine failure: EBUSY, from a mount or a logical
    volume still holding the device, means the image is still attached.
    """
    loop = os.path.basename(device_name)
    if not os.path.exists(f"/sys/block/{loop}/loop/backing_file"):
        logging.debug(f"{device_name} is already detached.")
        return

    result = subprocess.run(
        ["losetup", "--detach", device_name],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode:
        logging.warning(
            f"Failed to detach {device_name}: {result.stderr.strip()}"
        )

def get_loop_device():
    """Resolve ${loopdev:} - return the pinned or next free loop device."""
    if not hasattr(get_loop_device, "loopdev"):
        # OmegaConf resolves interpolation arguments eagerly, so this runs
        # even when it is only the fallback in ${oc.env:LOOPDEV,${loopdev:}}.
        # When CI pins one loop device per parallel flavor build via LOOPDEV,
        # honor the pin and skip the atexit detach: sibling processes all
        # cache the same lowest free device (another flavor's pinned one)
        # and would detach it mid-build when they exit.
        pinned = os.environ.get("LOOPDEV")
        if pinned:
            get_loop_device.loopdev = pinned
        else:
            get_loop_device.loopdev = os.popen("losetup -f").read().strip()
            atexit.register(clean_loop_device, get_loop_device.loopdev)

    return get_loop_device.loopdev


# Longest container id kept in a volume group name. Long enough to hold a
# Docker short id (12 hex digits) or the generated tail of a Kubernetes pod
# name whole, short enough that '<vg>-<lv>' stays readable in dmsetup output.
VG_SUFFIX_MAX = 24


def get_container_id():
    """Name identifying this container, or the host when not in one.

    Docker writes the short container id to /etc/hostname and Kubernetes
    writes the pod name, so the file answers "which container am I" without
    needing a runtime socket or any privilege the build does not already
    have.
    """
    try:
        with open("/etc/hostname", encoding="utf-8") as f:
            name = f.read().strip()
    except OSError:
        name = ""
    return name or os.uname().nodename.strip()


def get_vg_suffix():
    """Resolve ${vgsuffix:} - a discriminator unique to this container.

    Volume group names are not container-private: device-mapper names and
    /dev/<vg> live in the kernel, shared by every container on the host. Two
    concurrent builds of one flavor therefore provision the same group name,
    and each build both deactivates that name when it finishes and removes it
    before it starts -- so whichever build is mid-flight when its sibling
    starts or ends silently loses its logical volumes and fails later, where
    the cause is no longer visible ("No such file or directory" on a volume
    it created a second earlier).

    The container id is the discriminator, and its stability matters as much
    as its uniqueness: a rerun after a failed build has to resolve the same
    name as the run that left the group behind, or the cleanup stage cannot
    find it and the stale group holds its loop device open until the node
    reboots. Anything per-process -- a pid, a timestamp -- would be unique
    and leak.

    Set VG_SUFFIX to override, as CI does to name groups after the build
    number. That is also the way out when containers share the host's UTS
    namespace ('--uts=host', or '--network=host' in some runtimes): every
    container reports the host's name there, so ids stop being distinct.
    """
    if not hasattr(get_vg_suffix, "suffix"):
        # As with LOOPDEV above, OmegaConf resolves interpolation arguments
        # eagerly, so this runs even when it is only the fallback in
        # ${oc.env:VG_SUFFIX,${vgsuffix:}}. Honor the pin here too, so a
        # pinned build neither reads a hostname it will not use nor warns
        # about one it cannot read.
        pinned = os.environ.get("VG_SUFFIX")
        if pinned is not None:
            get_vg_suffix.suffix = pinned
            return get_vg_suffix.suffix

        # Keep only what LVM accepts in a group name. Hyphens are accepted,
        # but device-mapper escapes them by doubling them in the
        # /dev/mapper name, so a pod name would surface there as
        # 'simaai_minimal_elxr--builder--1123-rootfs.A'; underscores keep it
        # readable. Keep the tail, because a pod name carries its entropy in
        # the generated suffix -- dropping the front is what keeps two pods
        # of the same job apart.
        ident = re.sub(r"[^A-Za-z0-9]+", "_", get_container_id())
        ident = ident[-VG_SUFFIX_MAX:].strip("_")
        if not ident:
            LOG.warning(
                "No container id in /etc/hostname or uname: volume group "
                "names are shared with every other build on this host. Set "
                "VG_SUFFIX to a unique value to build in parallel."
            )
        get_vg_suffix.suffix = f"_{ident}" if ident else ""
        LOG.debug("Volume group suffix: '%s'", get_vg_suffix.suffix)

    return get_vg_suffix.suffix


OmegaConf.register_new_resolver("loopdev", get_loop_device)
OmegaConf.register_new_resolver("vgsuffix", get_vg_suffix)
OmegaConf.register_new_resolver("package", package_constructor)
OmegaConf.register_new_resolver("concat", lambda a, b: a + b)
