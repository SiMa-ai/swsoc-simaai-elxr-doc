"""
Copyright (c) 2024-2025 Wind River Systems, Inc.

SPDX-License-Identifier: Apache-2.0
"""

import logging
import shlex
import subprocess
import os

from pasha import utils
from pasha.context import Context
from pasha.log import complete_step, die
from pasha.modules.base import ModuleBase
from pasha.mount import mount_disk


class Command(ModuleBase):
    """Run a shell command in the chroot."""

    def __init__(self, state, config, stage):
        self.state = state
        self.config = config
        self.stage = stage

        self.context = Context(self.state, self.config, self.stage)

    def run(self):
        with mount_disk(self.context.params.disk, self.context.root):
            for cmd in self.context.stage.commands:
                with complete_step(f"Running {cmd}"):
                    with utils.Chroot(self.context, self.context.root) as chroot:
                        chroot.run(shlex.split(cmd))


class ShellCommand(ModuleBase):
    """Run a command on the mounted disk."""

    def __init__(self, state, config, stage):
        self.state = state
        self.config = config
        self.stage = stage

        self.context = Context(self.state, self.config, self.stage)

    def run(self):
        env = os.environ.copy()

        env["WORKSPACE_RS"] = str(self.context.workspace)

        commands = self.context.stage.get("commands") or []
        from_root_dir = self.context.stage.get("from_root_dir", False)
        # SiMa.ai: a failing command used to be ignored, so a stage that built
        # part of the image -- mke2fs, dd, tar, gzip -- could fail and still let
        # the build finish and produce a flashable artifact with a corrupt
        # payload. Stop on failure instead. Stages that genuinely tolerate one,
        # such as detaching a loop device that was never attached, either end in
        # "|| true" already or can set ignore_errors.
        ignore_errors = self.context.stage.get("ignore_errors", False)
        # SiMa.ai: run_shell stages (e.g. loop-device cleanup) must not mount the
        # disk; stages that need the rootfs mount it themselves (installer.unpack,
        # simaai.bootloader).
        for cmd in commands:
            with complete_step(f"Running {cmd}"):
                cwd = self.context.root if from_root_dir else None
                result = subprocess.run(cmd, shell=True, cwd=cwd, env=env)
                if result.returncode and not ignore_errors:
                    die(f"Command failed with {result.returncode}: {cmd}")
