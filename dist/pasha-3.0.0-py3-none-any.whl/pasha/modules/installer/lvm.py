"""
Copyright (c) 2026 SiMa.ai Technologies, Inc.

SPDX-License-Identifier: Apache-2.0
"""

import logging
import os
import subprocess

from pasha import lvm
from pasha.context import Context
from pasha.log import complete_step, die
from pasha.modules.base import ModuleBase
from pasha.modules.installer.disk import make_filesystem


class Lvm(ModuleBase):
    """Provision an LVM volume group and its logical volumes.

    Used for the "combined boot + LVM" eMMC layout, where a single
    physical volume holds the rootfs A/B slots and the persistent data
    volume so they can be resized in the field without repartitioning.

    Volumes are allocated in the order they are listed, so a volume using
    'extents: 100%FREE' has to come last.

    The board boots without an initramfs, so nothing activates the group
    before switch-root. Instead the 'dm_init' option writes the linear
    device-mapper tables for the rootfs slots to the workspace as a
    U-Boot-importable environment fragment; the bootloader stage installs
    it on the boot partition and the boot script imports it and passes
    the active slot's table to the kernel via dm-mod.create=.
    """

    def __init__(self, state, config, stage):
        self.state = state
        self.config = config
        self.stage = stage

        self.context = Context(self.state, self.config, self.stage)

        self.device = self.context.stage.get("device")
        if not self.device:
            die("LVM physical volume device is not specified.")

        self.vg = self.context.stage.get("vg")
        if not self.vg:
            die("LVM volume group name is not specified.")

        self.volumes = self.context.stage.get("volumes") or []
        if not self.volumes:
            die("No logical volumes are specified.")

        self.extent_size = self.context.stage.get("extent_size")
        self.dm_init = self.context.stage.get("dm_init")

    def run(self):
        lvm.create(
            self.vg,
            self.device,
            [dict(volume) for volume in self.volumes],
            self.extent_size,
        )

        with complete_step(f"Formatting logical volumes in {self.vg}"):
            for volume in self.volumes:
                fs = volume.get("fs")
                if not fs:
                    continue
                name = volume["name"]
                path = lvm.wait_for_lv(self.vg, name)
                make_filesystem(
                    path,
                    name,
                    volume.get("label", name),
                    fs,
                    volume.get("options") or None,
                )

        if self.dm_init:
            self._write_dm_tables()

    def _write_dm_tables(self):
        """Emit the per-slot dm-init tables read back from real extents.

        The offsets have to come from LVM rather than from the requested
        sizes: LVM rounds every volume up to a whole physical extent, so
        computing them from the yaml would drift from the image as soon
        as a size stops being extent-aligned.
        """
        volumes = lvm.extent_map(self.vg, self.device)

        name = self.dm_init.get("name", "rootfs")
        readonly = self.dm_init.get("readonly", False)
        slots = self.dm_init.get("slots") or {}
        if not slots:
            die("dm_init needs a slot to logical volume mapping.")

        output = self.context.workspace.joinpath(
            self.dm_init.get("output", "lvm-slots.env")
        )

        # Offset and length are emitted separately from the ready-made
        # table so the boot script can name the physical volume itself
        # (/dev/mmcblk${devnum}p2), which the build cannot know. The full
        # table is written too, for reference when debugging a board.
        reference = self.dm_init.get("device", "/dev/mmcblk0p2")

        lines = [f"lvm_vg={self.vg}", f"dm_name={name}"]
        lines.append(f"dm_flags={'ro' if readonly else 'rw'}")
        # The slots this image describes. A layout may leave a slot's volume
        # to be created on the board, and a consumer of this file has to be
        # able to tell that from a table that is missing by mistake.
        lines.append("dm_slots=" + " ".join(sorted(s.lower() for s in slots)))
        for slot, volume in sorted(dict(slots).items()):
            if volume not in volumes:
                die(f"Slot {slot} refers to unknown logical volume {volume}.")
            extents = volumes[volume]
            key = slot.lower()
            table = lvm.dm_table(
                name, extents["start"], extents["sectors"], reference, readonly
            )
            logging.info(f"Slot {slot} ({volume}): {table}")
            lines.append(f"lvname_{key}={volume}")
            lines.append(f"dmoff_{key}={extents['start']}")
            lines.append(f"dmlen_{key}={extents['sectors']}")
            lines.append(f"dmtable_{key}={table}")

        with open(output, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        logging.info(f"Wrote slot tables to {output}")


class LvmTeardown(ModuleBase):
    """Deactivate a volume group so the image can be detached.

    Active logical volumes keep the loop device open, so this must run
    before the image is detached or compressed. pasha also deactivates
    the group at exit, but doing it explicitly keeps the failure visible
    in the build log instead of surfacing as a stuck loop device.
    """

    def __init__(self, state, config, stage):
        self.state = state
        self.config = config
        self.stage = stage

        self.context = Context(self.state, self.config, self.stage)
        self.vg = self.context.stage.get("vg")
        if not self.vg:
            die("LVM volume group name is not specified.")
        self.skip_activation = self.context.stage.get("skip_activation") or []

    def run(self):
        # Flag the volumes the kernel maps itself, now that the build has
        # finished writing to them. Done here rather than at creation time
        # because the build needs them active to format and populate.
        for name in self.skip_activation:
            with complete_step(f"Marking {self.vg}/{name} activation-skipped"):
                lvm.set_activation_skip(self.vg, name)

        with complete_step(f"Deactivating volume group {self.vg}"):
            lvm.deactivate(self.vg)
            # Push the loop device's writeback through to the image file
            # before the next stage compresses it.
            subprocess.run(["sync"], check=False)
