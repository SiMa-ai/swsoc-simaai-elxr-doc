"""
Copyright (c) 2024 Wind River Systems, Inc.

SPDX-License-Identifier: Apache-2.0
"""

import logging
import os
import shutil

from pasha.archive import unpack
from pasha.context import Context
from pasha.log import complete_step, die
from pasha.modules.base import ModuleBase
from pasha.mount import mount_disk


class Unpack(ModuleBase):
    """Unpack a tarball to one or more disks."""

    def __init__(self, state, config, stage):
        self.state = state
        self.config = config
        self.stage = stage

        self.context = Context(self.state, self.config, self.stage)

        if not os.path.exists(self.context.params.source):
            die(f"{self.context.params.source} is not found.")

        # SiMa.ai: an A/B layout needs the same rootfs in every slot, so the
        # stage takes a list of targets and extracts into each. Extracting
        # rather than copying the first target into the rest keeps the slots
        # identical by construction: hard links, sparse regions and extended
        # attributes come out the same because it is the same operation, and
        # each volume keeps the label and UUID its own mkfs gave it.
        #
        # params.rootpart remains the single-target fallback, so a
        # configuration that names no slots behaves exactly as before. Read it
        # with .get() rather than as an attribute: a config that has neither
        # should get the message below, not an omegaconf traceback.
        targets = self.context.stage.get("targets")
        if not targets:
            fallback = self.context.params.get("rootpart")
            if not fallback:
                die(
                    "No partition to unpack into.",
                    hint=(
                        "List them under the stage's 'targets' option, or set "
                        "params.rootpart for a single-rootfs layout."
                    ),
                )
            targets = [fallback]

        self.targets = [str(t) for t in targets]

        for target in self.targets:
            if not os.path.exists(target):
                die(f"{target} is not found.")

    def run(self):
        with complete_step(f"Unpacking {self.context.params.source}"):
            for target in self.targets:
                logging.info(f"Unpacking into {target}.")
                with mount_disk(target, self.context.root):
                    unpack(self.context.params.source, self.context.root)
