"""
Copyright (c) 2025 Sima Technologies, Inc.

SPDX-License-Identifier: Apache-2.0
"""
