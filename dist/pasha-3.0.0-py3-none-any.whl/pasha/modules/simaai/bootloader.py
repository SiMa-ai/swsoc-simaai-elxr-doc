"""
Copyright (c) 2025-2026 SiMa.ai Technologies, Inc.

SPDX-License-Identifier: Apache-2.0
"""

import os
import logging
import shutil
from pasha import utils
from pasha.context import Context
from pasha.modules.base import ModuleBase
from pasha.mount import mount_disk
from pathlib import Path

# A/B slots, in partition order. Every slot's boot file system is written,
# whether or not its rootfs volume is populated: the payload is one small
# image, and a slot an update later fills needs its boot artifacts anyway.
SLOTS = ("a", "b")

# Headroom over the measured payload when sizing the boot file system image.
# Small because the image is grown to fill its partition once written; this
# only has to cover metadata and leave the artifact worth shipping.
BOOTFS_SLACK_MB = 32

# Largest fip.bin the boot chain can load: tRoot publishes a fixed fip_len of
# FIP_IMG_SPI_SZ (troot boot0/src/loader.h) to the A65, and ATF reserves the
# same SIMAAI_FIP_DDR_SIZE window. Both are 3 MB.
FIP_MAX_SIZE = 0x300000


class Bootloader(ModuleBase):
    """Populate the per-slot vfat boot file systems of the boot A/B + LVM layout.

    Every slot has a boot partition of its own, and every artifact the A65
    boot chain needs is a file at that partition's root:

        /u-boot.bin       loaded by tRoot
        /boot.scr.uimg    U-Boot boot script
        /fitImage         signed kernel FIT, booted via `bootm`; when the
                          kernel ships none, /Image (or /Image.enc) instead
        /fip.bin          TBBR FIP (BL2/BL31/BL32/BL33 + certs), every flavor
        /*.dtb            device trees
        /*.dtbo           device tree overlays
        /dm-table.env     this slot's rootfs dm-init offset and length,
                          absent while the slot has no rootfs volume
        /uboot.env        U-Boot environment

    A file system per slot, rather than one shared file system with a
    directory per slot, because a shared file system is a shared failure
    domain: an interrupted write while updating the inactive slot could take
    the active slot's boot artifacts with it, which is the one failure A/B
    exists to prevent.

    Separate partitions, near-identical contents: the payload is built once
    into a FAT32 image and written to every slot, so the slots are the same
    bytes by construction rather than by repeating the work. Only the
    per-slot pieces are stamped after the write: dm-table.env, which carries
    just the table of the slot holding it, and the file system label and
    volume id.
    """

    def __init__(self, state, config, stage):
        self.state = state
        self.config = config
        self.stage = stage

        self.logging = logging.getLogger(__name__)
        self.context = Context(self.state, self.config, self.stage)
        self.disk = self.context.stage.get("disk")
        self.image = self.context.stage.get("image")
        self.arch = self.context.stage.get("arch")
        self.cpio = self.context.stage.get("cpio")
        self.tftp = self.context.stage.get("tftp")

        # One boot partition per slot, in slot order. Defaults to the leading
        # partitions of the disk, which is where this layout puts them.
        self.bootparts = [str(p) for p in (self.context.stage.get("bootparts") or [])]
        if not self.bootparts:
            self.bootparts = [f"{self.disk}p{n}" for n in range(1, len(SLOTS) + 1)]
        if len(self.bootparts) != len(SLOTS):
            raise Exception(
                f"{len(self.bootparts)} boot partitions given for "
                f"{len(SLOTS)} slots {SLOTS}"
            )

        self.rootfs = self.context.root
        self.stagedir = self.context.workspace.joinpath("bootstage")

        # Standalone boot file system, built once and written to every slot.
        # Defaults into the workspace; the image build points it beside the
        # image, because it is also the payload an update writes to the
        # inactive slot.
        self.bootimg = Path(
            self.context.stage.get("boot_image")
            or self.context.workspace.joinpath("boot.vfat")
        )

        # One UUID per slot, in slot order, stamped after the shared image is
        # written. Optional: without them both slots keep the image's UUID.
        self.bootuuids = [str(u) for u in
                          (self.context.stage.get("bootuuids") or [])]
        if self.bootuuids and len(self.bootuuids) != len(SLOTS):
            raise Exception(
                f"{len(self.bootuuids)} boot UUIDs given for "
                f"{len(SLOTS)} slots {SLOTS}"
            )

    def dm_table(self, slot):
        """Return one slot's dm-init table as U-Boot-importable text.

        Per-slot rather than one shared file describing both: each boot
        partition carries only its own slot's table, so nothing on the
        active boot partition has to change when the other slot's volumes
        are rewritten or resized - the active partition stays read-only at
        runtime. The table is therefore written into each partition after
        the shared image, next to the label and volume id, rather than into
        the shared payload.

        Returns None for a slot the lvm stage did not describe, which means
        the image has no volume for it and none can be described from here:
        the volume is created on the board, at extents this build cannot
        know, and the update that populates the slot writes the table.

        A table missing for a slot that does have a volume fails the build.
        There is nothing to degrade to: the boot script warns and carries on
        with dmoff and dmlen unset, and U-Boot has no compiled-in default for
        either, so dm-mod.create= gets a table with holes in it and the kernel
        cannot map the rootfs. An image that cannot boot is worth stopping a
        build over, where a warning in an image build's log is not something
        anyone reads in time.
        """
        tables = self.context.workspace.joinpath("lvm-slots.env")
        if not tables.exists():
            raise Exception(
                f"{tables} not found, so no rootfs dm-init table can be "
                "written to the boot partitions and the image would not "
                "boot. Does the installer.disk.lvm stage declare dm_init?"
            )

        recorded = {}
        for line in tables.read_text(encoding="utf-8").splitlines():
            name, _, value = line.partition("=")
            if value:
                recorded[name] = value

        # Absent dm_slots means the lvm stage predates the marker, so fall
        # through and let a missing entry fail as it always did.
        declared = recorded.get("dm_slots", "").split()
        if declared and slot not in declared:
            return None

        try:
            lines = [
                f"dm_name={recorded['dm_name']}",
                f"dm_flags={recorded['dm_flags']}",
                f"dmoff={recorded[f'dmoff_{slot}']}",
                f"dmlen={recorded[f'dmlen_{slot}']}",
            ]
        except KeyError as missing:
            raise Exception(
                f"{tables.name} has no {missing} entry"
            ) from None

        return "\n".join(lines) + "\n"

    def stage_payload(self):
        """Build one copy of the per-slot file set, and the tftp artifacts.

        Built once in the workspace and then copied into every slot, so the
        slots are identical by construction rather than by repeating the same
        globs against the rootfs twice.
        """
        boot = self.rootfs.joinpath("boot")

        # One u-boot-<platform> build serves every flavor and ships at /boot/;
        # it decides at boot, from tRoot's secure flag, whether to enforce the
        # kernel-FIT signature. The flavors differ only in the troot package,
        # whose blobs sit at /boot/{Debug,Release} either way.
        ubootbin = boot.joinpath("u-boot.bin")
        netboot = boot.joinpath("netboot.scr.uimg")
        trootdbg_dir = boot.joinpath("Debug")
        trootrel_dir = boot.joinpath("Release")
        trootdbg_blob = trootdbg_dir.joinpath("troot_blob.be")

        shutil.rmtree(self.stagedir, ignore_errors=True)
        self.stagedir.mkdir(parents=True)

        # u-boot is no longer dd'd to raw partitions: every copy is a file on
        # its slot's boot file system, so a bootloader update is part of the
        # same atomic A/B swap as the kernel.
        for name in ("boot.scr.uimg", "u-boot.bin", "uboot.env",
                     "uboot-redund.env"):
            shutil.copy(boot.joinpath(name), self.stagedir)

        rootfs_cpio = f"{self.cpio}{'.gz'}"
        if not os.path.isdir(self.tftp):
            os.makedirs(self.tftp)

        # Install rootfs cpio image to tftp artifacts
        shutil.copy(rootfs_cpio, self.tftp)
        shutil.copy(f"{ubootbin}", self.tftp)
        shutil.copy(f"{netboot}", self.tftp)
        shutil.copy(f"{trootdbg_blob}", self.tftp)
        shutil.rmtree(trootdbg_dir)
        shutil.rmtree(trootrel_dir)

        # The kernel package ships the signed FIT as /boot/fitImage; without
        # one, fall back to vmlinuz-* as Image / Image.enc.
        fit = boot.joinpath("fitImage")
        if fit.is_file():
            self.logging.info("Installing kernel FIT")
            shutil.copy(fit, self.stagedir.joinpath("fitImage"))
            shutil.copy(fit, os.path.join(self.tftp, "fitImage"))
        else:
            self.logging.info("No kernel FIT (/boot/fitImage) in the rootfs, "
                              "installing vmlinuz-* as Image")
            for f in boot.glob("vmlinuz-*"):
                if f.name.endswith(".enc"):
                    self.logging.info(f"Processing Encrypted Image: {f.name}")
                    target = self.stagedir.joinpath("Image.enc")
                else:
                    self.logging.info(f"Processing Standard Image: {f.name}")
                    target = self.stagedir.joinpath("Image")

                target_gz = target.with_suffix(target.suffix + ".gz")
                shutil.copyfile(f, target_gz)
                if utils.run_command(["gunzip", "-f", str(target_gz)])[0]:
                    raise Exception(
                        f"Kernel image decompression failed for {f.name}")
                shutil.copy(target, self.tftp)

        # Install the TBBR FIP alongside the FIT it authenticates. tRoot's
        # load_atf_fip() reads FIP.BIN from the root of each A/B vfat boot
        # partition (troot boot0/src/loader.c: load_fip_from_mmc), trying the
        # active slot first and the sibling second, and only falling back to
        # SPI-NOR -- which a full-chip erase is the only way to rewrite. So the
        # FIP rides in the shared payload next to the fitImage, exactly like it.
        #
        # Every flavor boots through TF-A, from the same fip.bin: tRoot's
        # secure flag decides whether it is anchored to the ROTPK and whether
        # OP-TEE runs. An image without one would boot only because tRoot fell
        # back to whatever is already in SPI-NOR -- a stale firmware image that
        # looks like a successful build -- so a missing FIP fails the build.
        fip = boot.joinpath("fip.bin")
        if not fip.is_file():
            raise Exception(
                "no /boot/fip.bin in the rootfs: atf-<platform> is not "
                "installed in the image. Every flavor needs it; it belongs in "
                "pboot_common in configs/images/image-params.yaml."
            )
        # tRoot publishes a fixed fip_len of FIP_IMG_SPI_SZ (3 MB) to the A65,
        # so a larger FIP is read short and BL1 fails on a truncated cert
        # chain -- a failure that looks like a bad signature rather than an
        # oversize image. Refuse it here instead.
        if fip.stat().st_size > FIP_MAX_SIZE:
            raise Exception(
                f"fip.bin is {fip.stat().st_size} bytes, exceeding the "
                f"{FIP_MAX_SIZE}-byte window tRoot publishes "
                f"(FIP_IMG_SPI_SZ in troot boot0/src/loader.h)"
            )
        self.logging.info(f"Installing TBBR FIP: {fip.name} "
                          f"({fip.stat().st_size} bytes)")
        shutil.copy(fip, self.stagedir.joinpath("fip.bin"))
        shutil.copy(fip, os.path.join(self.tftp, "fip.bin"))
        for f in self.rootfs.glob("lib/linux-image-*/simaai/*.dtb"):
            shutil.copy(f, self.stagedir)
            shutil.copy(f, self.tftp)

        # Overlays go flat into the slot's file system, not into an overlays/
        # subdirectory: the boot script loads them as bare file names. The
        # tftp tree keeps its own overlays/ layout, which netboot.cmd and
        # usbboot.cmd address as overlays/${dtbo}.
        tftp_overlay_dir = os.path.join(self.tftp, "overlays")
        Path(tftp_overlay_dir).mkdir(exist_ok=True)
        for f in self.rootfs.glob("lib/linux-image-*/simaai/overlays/*.dtbo"):
            shutil.copy(f, self.stagedir)
            shutil.copy(f, tftp_overlay_dir)

    def build_bootfs(self):
        """Build the staged payload into one vfat image.

        mkfs.vfat on a plain file plus mcopy populates the image without
        mounting anything and without privileged loop access, and produces
        the artifact an update installs: what a freshly flashed slot holds
        and what an update writes to the inactive slot are the same bytes.

        FAT32 is forced. tRoot reads this file system with a FAT32-only
        reader (vfat.c parses sectors_per_fat_32 and root_cluster), while
        mkfs.vfat left to its own devices picks FAT16 for partitions this
        size - which would leave tRoot unable to reach the slot's u-boot
        and falling back to SPI-NOR without being able to say why.

        Sized to the boot partition rather than the payload: vfat has no
        resize step, so building at partition size is what leaves free
        space for artifacts added later. The zeros compress away in the
        shipped bundle and dd conv=sparse keeps them off the disk image.
        """
        rc, out = utils.run_command(
            ["blockdev", "--getsize64", self.bootparts[0]])
        if rc:
            raise Exception(f"Failed to size {self.bootparts[0]}")
        size_kb = int(out.split()[0]) // 1024

        self.bootimg.parent.mkdir(parents=True, exist_ok=True)
        self.bootimg.unlink(missing_ok=True)
        if utils.run_command([
            "mkfs.vfat", "-C", "-F", "32", "-n", "BOOT",
            str(self.bootimg), str(size_kb),
        ])[0]:
            raise Exception(f"Failed to build boot file system {self.bootimg}")

        # u-boot.bin first: FAT directory order is creation order, and
        # tRoot's 8.3 scan finds it fastest at the front. Everything else
        # follows sorted, for reproducibility.
        entries = sorted(str(p) for p in self.stagedir.iterdir())
        front = str(self.stagedir.joinpath("u-boot.bin"))
        if front in entries:
            entries.remove(front)
            entries.insert(0, front)
        if utils.run_command(
                ["mcopy", "-i", str(self.bootimg), "-s", "-Q"]
                + entries + ["::/"])[0]:
            raise Exception(f"Failed to populate {self.bootimg}")

        self.logging.info(f"Built {self.bootimg} ({size_kb // 1024}M vfat)")

    def install_slot(self, slot, part, volid):
        """Write the boot image to one partition and stamp its identity.

        conv=sparse keeps the payload's holes as holes in the image, which is
        only safe because the boot partitions are not formatted beforehand;
        there is nothing underneath for a skipped block to expose.

        The image carries one label and one volume id, so each slot is
        stamped with its own afterwards (FAT has no ext4-style UUID; blkid
        shows the 32-bit volume id as XXXX-XXXX). Nothing on the board
        addresses a boot partition by either -- U-Boot is handed the
        partition number and Linux the simaai.bootdev= that follows it --
        but both partitions are always visible, so sharing an id would make
        blkid and lsblk ambiguous, and the label is the only thing that
        says which slot a mounted /boot came from.

        The slot's own dm-table.env is written after the shared image for
        the same reason as the identity: it is the one file whose content
        is per-slot (see dm_table()).
        """
        label = f"BOOT_{slot.upper()}"

        if utils.run_command([
            "dd", f"if={self.bootimg}", f"of={part}", "bs=4M",
            "conv=sparse,fsync", "status=none",
        ])[0]:
            raise Exception(f"Failed to write boot image to {part}")

        table = self.dm_table(slot)
        if table is None:
            self.logging.info(
                f"Slot {slot} has no rootfs volume in this image, so {part} "
                "ships without a dm-table.env; the slot cannot be booted "
                "until an update populates it and writes one"
            )
        else:
            tablefile = self.context.workspace.joinpath(f"dm-table.{slot}.env")
            tablefile.write_text(table, encoding="utf-8")
            if utils.run_command([
                "mcopy", "-i", part, "-o",
                str(tablefile), "::/dm-table.env",
            ])[0]:
                raise Exception(f"Failed to write dm-table.env to {part}")

        if utils.run_command(["fatlabel", part, label])[0]:
            raise Exception(f"Failed to label boot file system on {part}")
        if volid:
            volid = volid.replace("-", "")
            if utils.run_command(["fatlabel", "-i", part, volid])[0]:
                raise Exception(f"Failed to set volume id on {part}")

        self.logging.info(f"Installed slot {slot} on {part} as {label}")

    def run(self):
        # SiMa.ai: mount a rootfs for the duration of this stage. unpack no
        # longer leaves it mounted; mount_disk unmounts it on exit.
        #
        # Slot A, but only as an arbitrary choice of source: every slot holds
        # the same tree, and this stage only reads the kernel and device trees
        # out of it to build one payload that all slots then receive.
        with mount_disk(self.context.params.rootpart_a, self.rootfs):
            self.logging.info("Installing boot loader")
            self.stage_payload()

            self.build_bootfs()

            uuids = self.bootuuids or [None] * len(SLOTS)
            for slot, part, uuid in zip(SLOTS, self.bootparts, uuids):
                self.install_slot(slot, part, uuid)

            shutil.rmtree(self.stagedir, ignore_errors=True)
            self.logging.info(
                "Successfully installed boot loader and boot partitions"
            )
