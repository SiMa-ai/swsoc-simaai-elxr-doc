"""
Copyright (c) 2024-2025 Wind River Systems, Inc.

SPDX-License-Identifier: Apache-2.0
"""

import logging
import os
import subprocess
import sys

from pasha import exceptions, utils
from pasha.archive import compress
from pasha.context import Context
from pasha.log import complete_step, die
from pasha.modules.base import ModuleBase


class RawImage(ModuleBase):
    """Create a raw disk image."""

    def __init__(self, state, config, stage):
        self.state = state
        self.config = config
        self.stage = stage

        self.context = Context(self.state, self.config, self.stage)

        self.size = self.context.stage.get("size", None)
        if self.size is None:
            """Size of image, Valid unit size M and G (powers of 1024)."""
            raise exceptions.ConfigError("Disk size is not specified.")

        # FIXME(chuck) - Attach timestamp to image.
        self.image = self.context.stage.get("name", None)
        if self.image is None:
            """Name of image."""
            raise exceptions.ConfigError("Image name is not specified.")

    def run(self):
        with complete_step(f"Creating {self.image}"):
            if os.path.exists(self.image):
                logging.debug(f"Found existing {self.image}. Removing.")
                os.unlink(self.image)
        try:
            subprocess.run(
                ["truncate", "-s", self.size, self.image],
                capture_output=True,
                check=True,
            )
        except subprocess.CalledProcessError as e:
            die("Failed to create disk image: " + e.stderr.decode("utf-8").strip())
        # SiMa.ai: attach the image to the loop device with partition scanning
        # so the partitions created later are exposed as /dev/loopXpN for
        # parted/mkfs/unpack.
        try:
            subprocess.run(
                ["losetup", "--partscan", self.config.params.disk, self.image],
                capture_output=True,
                check=True,
            )
        except subprocess.CalledProcessError as e:
            die("Failed to create disk image: " + e.stderr.decode("utf-8").strip())

        # Prove the attach landed on OUR image. Loop devices are global to
        # the host and shared with every concurrent build; a pinned device
        # can be re-pointed by a sibling whose reservation went stale, and
        # every later write then lands in the wrong backing file while this
        # build ships zeros (SOCSW-6055). The kernel's answer, not losetup's
        # exit status, is what says whose file the device carries.
        loop = os.path.basename(self.config.params.disk)
        backing = ""
        try:
            with open(f"/sys/block/{loop}/loop/backing_file") as f:
                backing = f.read().strip()
        except OSError:
            pass
        if os.path.realpath(backing) != os.path.realpath(self.image):
            die(
                f"{self.config.params.disk} is backed by '{backing}', not "
                f"{self.image}: a concurrent build owns this device"
            )
