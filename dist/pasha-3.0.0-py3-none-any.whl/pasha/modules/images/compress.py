"""
Copyright (c) 2024-2025 Wind River Systems, Inc.

SPDX-License-Identifier: Apache-2.0
"""

import logging
import os

from pasha.archive import compress
from pasha.context import Context
from pasha.log import complete_step, die
from pasha.modules.base import ModuleBase


class CompressImage(ModuleBase):
    def __init__(self, state, config, stage):
        self.state = state
        self.config = config
        self.stage = stage

        self.context = Context(self.state, self.config, self.stage)
        self.compressor = self.context.stage.get("compression", "zstd")

    def run(self):
        # SiMa.ai: compress the image file, not params.disk. In the SiMa.ai
        # flow params.disk is a loop device (${loopdev:}) that undeploy has
        # already detached by this stage; the artifact to keep is the .img
        # file in params.image.
        with complete_step(f"Compressing {self.context.params.image}."):
            if not os.path.exists(self.context.params.image):
                die(f"{self.context.params.image} not found")

            # A disk image whose first MiB is all zeros has no partition
            # table: nothing this pipeline wrote ever reached the file. That
            # is the signature of the loop device having been re-pointed at
            # another build's backing mid-build (SOCSW-6055) - the stages all
            # succeed against a healthy device while this file stays sparse.
            # Shipping it would hand every consumer a 7.5 GiB stream of
            # zeros, so refuse here, where the cause is still diagnosable.
            with open(self.context.params.image, "rb") as f:
                head = f.read(1024 * 1024)
            if not any(head):
                die(
                    f"{self.context.params.image} contains no partition "
                    "table (first MiB is all zeros); the image writes never "
                    "reached this file - refusing to ship it"
                )

            compress(self.context.params.image, compressor=self.compressor)
