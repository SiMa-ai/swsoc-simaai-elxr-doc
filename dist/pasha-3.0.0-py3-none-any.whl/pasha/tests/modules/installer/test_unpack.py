"""
Copyright (c) 2024 Wind River Systems, Inc.

SPDX-License-Identifier: Apache-2.0

"""

import pathlib
import tempfile
from unittest import mock

from omegaconf import OmegaConf

from pasha.modules.installer import unpack
from pasha.tests import base


def _tar_call(rootfs, source="fake_source.tar.gz"):
    return mock.call(
        [
            "tar",
            "-C",
            rootfs,
            "--exclude=./dev/*",
            "-zxf",
            source,
            "--numeric-owner",
        ],
        check=True,
        capture_output=True,
    )


def _mount_calls(rootfs, volume):
    """The calls mount_disk makes for a device-mapper volume.

    A logical volume carries a bare file system with no partition table, so
    mount_disk mounts it directly instead of going through systemd-dissect.
    """
    return [
        mock.call(["mkdir", "-p", str(rootfs)], check=True),
        mock.call(["mount", volume, str(rootfs)], check=True),
    ]


def _umount_call(rootfs):
    return mock.call(["umount", str(rootfs)], check=False)


class TestUnpackMount(base.TestCase):
    def setUp(self):
        super(TestUnpackMount, self).setUp()
        self.state = mock.MagicMock()
        self.tempdir = pathlib.Path(tempfile.mkdtemp())
        self.state.workspace = self.tempdir
        self.config = OmegaConf.create(
            {
                "name": "fake_name",
                "architecture": "amd64",
                "params": {
                    "disk": "/dev/sda",
                    "source": "fake_source.tar.gz",
                    # The fallback key, kept for single-rootfs configurations.
                    # The A/B image build names its slots under 'targets'
                    # instead, as test_unpack_module_every_target does.
                    "rootpart": "/dev/mapper/fake_vg-rootfs.A",
                },
            }
        )

        self.stage = OmegaConf.create({})

    @property
    def rootfs(self):
        return self.state.workspace.joinpath("fake_name/rootfs")

    @mock.patch("subprocess.run")
    @mock.patch("os.path.exists")
    def test_unpack_module_with_mount(self, mock_exists, mock_run):
        """With no targets listed the stage falls back to params.rootpart."""
        expected_calls = [
            *_mount_calls(self.rootfs, "/dev/mapper/fake_vg-rootfs.A"),
            _tar_call(self.rootfs),
            _umount_call(self.rootfs),
        ]
        unpack.Unpack(self.state, self.config, self.stage).run()
        self.assertEqual(mock_run.call_args_list, expected_calls)

    @mock.patch("subprocess.run")
    @mock.patch("os.path.exists")
    def test_unpack_module_every_target(self, mock_exists, mock_run):
        """Each A/B rootfs slot is mounted and extracted into in turn."""
        stage = OmegaConf.create(
            {
                "targets": [
                    "/dev/mapper/fake_vg-rootfs.A",
                    "/dev/mapper/fake_vg-rootfs.B",
                ]
            }
        )
        expected_calls = []
        for volume in ("/dev/mapper/fake_vg-rootfs.A", "/dev/mapper/fake_vg-rootfs.B"):
            expected_calls.extend(_mount_calls(self.rootfs, volume))
            expected_calls.append(_tar_call(self.rootfs))
            expected_calls.append(_umount_call(self.rootfs))

        unpack.Unpack(self.state, self.config, stage).run()
        self.assertEqual(mock_run.call_args_list, expected_calls)

    @mock.patch("subprocess.run")
    @mock.patch("os.path.exists")
    def test_unpack_module_no_target_configured(self, mock_exists, mock_run):
        """Neither targets nor the fallback key is an error, not a traceback."""
        config = OmegaConf.create(
            {
                "name": "fake_name",
                "architecture": "amd64",
                "params": {"disk": "/dev/sda", "source": "fake_source.tar.gz"},
            }
        )

        self.assertRaises(
            SystemExit, unpack.Unpack, self.state, config, self.stage
        )
        mock_run.assert_not_called()

    @mock.patch("subprocess.run")
    @mock.patch("os.path.exists")
    def test_unpack_module_missing_target(self, mock_exists, mock_run):
        """A target that is not present stops the build before it mounts."""
        stage = OmegaConf.create({"targets": ["/dev/mapper/fake_vg-rootfs.B"]})
        mock_exists.side_effect = lambda path: path == "fake_source.tar.gz"

        self.assertRaises(
            SystemExit, unpack.Unpack, self.state, self.config, stage
        )
        mock_run.assert_not_called()
