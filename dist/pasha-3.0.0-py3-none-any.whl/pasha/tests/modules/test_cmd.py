"""
Copyright (c) 2024-2025 Wind River Systems, Inc.

SPDX-License-Identifier: Apache-2.0

"""

import os
import pathlib
import tempfile
from unittest import mock

from omegaconf import OmegaConf

from pasha.modules import cmd
from pasha.tests import base


class TestShellCommand(base.TestCase):
    def setUp(self):
        super(TestShellCommand, self).setUp()
        self.state = mock.MagicMock()
        self.tempdir = pathlib.Path(tempfile.mkdtemp())
        self.state.workspace = self.tempdir
        self.config = OmegaConf.create(
            {
                "name": "fake_name",
                "architecture": "amd64",
                "params": {
                    "disk": "/dev/sda",
                },
            }
        )
        self.stage = OmegaConf.create({"commands": ["pwd", "ls -lh"]})

    @property
    def workspace(self):
        return self.tempdir.joinpath("fake_name")

    @property
    def env(self):
        """The environment the module hands every command."""
        env = os.environ.copy()
        env["WORKSPACE_RS"] = str(self.workspace)
        return env

    def expected(self, cwd=None):
        return [
            mock.call("pwd", shell=True, cwd=cwd, env=self.env),
            mock.call("ls -lh", shell=True, cwd=cwd, env=self.env),
        ]

    @mock.patch("subprocess.run")
    def test_run_shell(self, mock_exec):
        """Commands run in the invoking directory, and the disk is not mounted."""
        mock_exec.return_value.returncode = 0
        cmd.ShellCommand(self.state, self.config, self.stage).run()
        self.assertEqual(mock_exec.call_args_list, self.expected())

    @mock.patch("subprocess.run")
    def test_run_shell_from_root_dir(self, mock_exec):
        mock_exec.return_value.returncode = 0
        stage = OmegaConf.create(
            {"commands": ["pwd", "ls -lh"], "from_root_dir": True}
        )
        cmd.ShellCommand(self.state, self.config, stage).run()
        self.assertEqual(
            mock_exec.call_args_list,
            self.expected(cwd=self.workspace.joinpath("rootfs")),
        )

    @mock.patch("subprocess.run")
    def test_run_shell_stops_on_failure(self, mock_exec):
        """A failing command ends the build instead of letting it finish."""
        mock_exec.return_value.returncode = 1
        self.assertRaises(
            SystemExit,
            cmd.ShellCommand(self.state, self.config, self.stage).run,
        )
        # The second command must not have run.
        self.assertEqual(mock_exec.call_count, 1)

    @mock.patch("subprocess.run")
    def test_run_shell_ignore_errors(self, mock_exec):
        """ignore_errors restores the old tolerance for stages that need it."""
        mock_exec.return_value.returncode = 1
        stage = OmegaConf.create(
            {"commands": ["pwd", "ls -lh"], "ignore_errors": True}
        )
        cmd.ShellCommand(self.state, self.config, stage).run()
        self.assertEqual(mock_exec.call_args_list, self.expected())
