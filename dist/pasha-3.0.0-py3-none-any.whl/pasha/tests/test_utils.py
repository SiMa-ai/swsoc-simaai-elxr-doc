"""
Copyright (c) 2024 Wind River Systems, Inc.

SPDX-License-Identifier: Apache-2.0

"""

import os
import re
import subprocess
from unittest import mock

import pytest

from pasha import utils
from pasha.tests import base

# Characters LVM accepts in a volume group name.
VG_NAME = re.compile(r"[A-Za-z0-9._+-]+")


class TestUtils(base.TestCase):
    def test_run_command(self):
        with mock.patch.object(subprocess, "Popen") as execute:
            utils.run_command(["ls", "foo"])
            execute.assert_called_once_with(
                ["ls", "foo"], stdout=-1, stderr=-2, stdin=-1, universal_newlines=True
            )

    def test_run_command_not_found(self):
        with pytest.raises(SystemExit):
            utils.run_command(["foo"])


class TestVgSuffix(base.TestCase):
    """Two builds on one host must never resolve the same group name.

    Device-mapper names are node-global, so a shared name lets one build's
    teardown remove a sibling's logical volumes; the sibling then fails on a
    volume it created seconds earlier.
    """

    def setUp(self):
        super().setUp()
        # The suffix is cached for the life of the process so every stage
        # resolves one name; drop the cache between cases.
        self.addCleanup(lambda: utils.get_vg_suffix.__dict__.pop("suffix", None))
        utils.get_vg_suffix.__dict__.pop("suffix", None)

    def _suffix(self, container_id, env=None):
        with mock.patch.dict(os.environ, env or {}, clear=True), \
             mock.patch.object(utils, "get_container_id", return_value=container_id):
            return utils.get_vg_suffix()

    def test_docker_short_id(self):
        """What Docker puts in /etc/hostname, kept whole."""
        self.assertEqual(self._suffix("1a2b3c4d5e6f"), "_1a2b3c4d5e6f")

    def test_pod_name_hyphens_become_underscores(self):
        """Hyphens are legal in a group name but doubled in /dev/mapper.

        'elxr-builder-abc' would reach dmsetup as 'elxr--builder--abc', which
        no longer reads as the pod it came from.
        """
        self.assertEqual(self._suffix("elxr-builder-abc"), "_elxr_builder_abc")

    def test_long_pod_name_keeps_the_tail(self):
        """A pod name carries its entropy in the generated suffix."""
        suffix = self._suffix("elxr-image-build-daily-1123-x7k9d")
        self.assertLessEqual(len(suffix), utils.VG_SUFFIX_MAX + 1)
        self.assertTrue(suffix.endswith("_1123_x7k9d"))

    def test_two_containers_differ(self):
        """The property the whole change exists for."""
        self.assertNotEqual(self._suffix("1a2b3c4d5e6f"), self._suffix("f6e5d4c3b2a1"))

    def test_name_stays_a_legal_volume_group(self):
        for container_id in ("1a2b3c4d5e6f", "elxr.builder-1123_x", "HOST/odd:name"):
            with self.subTest(container_id=container_id):
                vg = "simaai_minimal" + self._suffix(container_id)
                self.assertRegex(vg, VG_NAME)
                self.assertTrue(VG_NAME.fullmatch(vg))

    def test_vg_suffix_overrides(self):
        """CI names groups after the build number."""
        self.assertEqual(
            self._suffix("1a2b3c4d5e6f", {"VG_SUFFIX": "_b1123"}), "_b1123"
        )

    def test_empty_vg_suffix_is_an_opt_out(self):
        """Set but empty asks for the bare name, as ${oc.env:} reads it."""
        self.assertEqual(self._suffix("1a2b3c4d5e6f", {"VG_SUFFIX": ""}), "")

    def test_no_container_id_falls_back_to_the_bare_name(self):
        """Nothing to discriminate with: keep building, but say so."""
        with mock.patch.object(utils.LOG, "warning") as warn:
            self.assertEqual(self._suffix(""), "")
        warn.assert_called_once()

    def test_suffix_is_resolved_once(self):
        """Every stage has to see the same group name."""
        with mock.patch.dict(os.environ, {}, clear=True), \
             mock.patch.object(
                 utils, "get_container_id", return_value="1a2b3c4d5e6f"
             ) as container_id:
            self.assertEqual(utils.get_vg_suffix(), utils.get_vg_suffix())
        container_id.assert_called_once()


class TestContainerId(base.TestCase):
    def test_reads_etc_hostname(self):
        with mock.patch("builtins.open", mock.mock_open(read_data="1a2b3c4d5e6f\n")):
            self.assertEqual(utils.get_container_id(), "1a2b3c4d5e6f")

    def test_empty_etc_hostname_falls_back_to_uname(self):
        with mock.patch("builtins.open", mock.mock_open(read_data="\n")), \
             mock.patch("os.uname", return_value=mock.Mock(nodename="builder")):
            self.assertEqual(utils.get_container_id(), "builder")

    def test_unreadable_etc_hostname_falls_back_to_uname(self):
        with mock.patch("builtins.open", side_effect=OSError), \
             mock.patch("os.uname", return_value=mock.Mock(nodename="builder")):
            self.assertEqual(utils.get_container_id(), "builder")
