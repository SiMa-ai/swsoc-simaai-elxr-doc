"""
Copyright (c) 2026 SiMa.ai Technologies, Inc.

SPDX-License-Identifier: Apache-2.0

"""

import os
import stat
from unittest import mock

from pasha import mount
from pasha.tests import base

DM_MAJOR = 252

# The two names LVM gives one logical volume. With 'udev_rules = 0' the
# mapper name is the real block node and the /dev/<vg>/<lv> name is a
# symlink to it, so realpath() stops at the mapper name.
LV_LINK = "/dev/fake_vg/rootfs.A"
LV_NODE = "/dev/mapper/fake_vg-rootfs.A"


def _stat(kind, major):
    mode = stat.S_IFBLK if kind == "blk" else stat.S_IFREG
    return mock.Mock(st_mode=mode | 0o600, st_rdev=os.makedev(major, 0))


class TestIsDeviceMapper(base.TestCase):
    """Every /dev name a logical volume can arrive under must be recognised.

    Missing one is not a cosmetic problem: mount_disk falls through to
    systemd-dissect, whose --umount detaches the loop device backing the
    volume group and leaves the next stage with no volume group at all.
    """

    def _detect(self, path, real, st=("blk", DM_MAJOR)):
        with mock.patch("os.path.realpath", return_value=real), \
             mock.patch("os.stat", return_value=_stat(*st)), \
             mock.patch.object(mount, "_dm_major", return_value=DM_MAJOR):
            return mount._is_device_mapper(path)

    def test_mapper_node(self):
        """The name libdevmapper creates without udev."""
        self.assertTrue(self._detect(LV_NODE, LV_NODE))

    def test_vg_symlink_without_udev(self):
        """The regression: /dev/<vg>/<lv> resolving only as far as the mapper name."""
        self.assertTrue(self._detect(LV_LINK, LV_NODE))

    def test_vg_symlink_with_udev(self):
        """With udev the same symlink chain reaches /dev/dm-*."""
        self.assertTrue(self._detect(LV_LINK, "/dev/dm-3"))

    def test_dm_node_under_neither_prefix(self):
        """A dm node named elsewhere is still a dm node, by major number."""
        self.assertTrue(self._detect("/run/lv", "/run/lv"))

    def test_whole_disk_loop_is_not_dm(self):
        """A whole-disk loop image must still go to systemd-dissect."""
        self.assertFalse(self._detect("/dev/loop14", "/dev/loop14", ("blk", 7)))

    def test_regular_file_is_not_dm(self):
        self.assertFalse(self._detect("/work/disk.img", "/work/disk.img", ("reg", 0)))

    def test_missing_path_is_not_dm(self):
        with mock.patch("os.path.realpath", return_value="/dev/nope"), \
             mock.patch("os.stat", side_effect=FileNotFoundError), \
             mock.patch.object(mount, "_dm_major", return_value=DM_MAJOR):
            self.assertFalse(mount._is_device_mapper("/dev/nope"))

    def test_no_device_mapper_in_proc_devices(self):
        """Without a dm major there is nothing to compare against."""
        with mock.patch("os.path.realpath", return_value="/dev/foo"), \
             mock.patch.object(mount, "_dm_major", return_value=None):
            self.assertFalse(mount._is_device_mapper("/dev/foo"))


class TestDmMajor(base.TestCase):
    def test_parses_proc_devices(self):
        proc = "Block devices:\n  7 loop\n252 device-mapper\n259 blkext\n"
        with mock.patch("builtins.open", mock.mock_open(read_data=proc)):
            self.assertEqual(mount._dm_major(), 252)

    def test_absent_device_mapper(self):
        with mock.patch("builtins.open", mock.mock_open(read_data="  7 loop\n")):
            self.assertIsNone(mount._dm_major())

    def test_unreadable_proc_devices(self):
        with mock.patch("builtins.open", side_effect=OSError):
            self.assertIsNone(mount._dm_major())


class TestMountDiskDispatch(base.TestCase):
    """A logical volume is mounted directly, never through systemd-dissect."""

    @mock.patch("subprocess.run")
    def test_logical_volume_mounts_directly(self, mock_run):
        with mock.patch("os.path.realpath", return_value=LV_NODE), \
             mock.patch("os.stat", return_value=_stat("blk", DM_MAJOR)), \
             mock.patch.object(mount, "_dm_major", return_value=DM_MAJOR):
            with mount.mount_disk(LV_LINK, "/mnt/rootfs"):
                pass

        self.assertEqual(
            mock_run.call_args_list,
            [
                mock.call(["mkdir", "-p", "/mnt/rootfs"], check=True),
                mock.call(["mount", LV_LINK, "/mnt/rootfs"], check=True),
                mock.call(["umount", "/mnt/rootfs"], check=False),
            ],
        )

    @mock.patch("subprocess.run")
    def test_no_disk_yields_nothing(self, mock_run):
        with mount.mount_disk(None, "/mnt/rootfs") as got:
            self.assertIsNone(got)
        mock_run.assert_not_called()
