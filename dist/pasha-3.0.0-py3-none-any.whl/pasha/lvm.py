"""
Copyright (c) 2026 SiMa.ai Technologies, Inc.

SPDX-License-Identifier: Apache-2.0

LVM helpers for the "combined boot + LVM" eMMC layout: one ext4 boot
partition plus a single LVM physical volume holding the rootfs A/B slots
and the persistent data volume.

The target boots without an initramfs, so LVM userspace never runs before
switch-root. Instead the kernel is handed a dm-init table
(dm-mod.create=) describing the active rootfs logical volume as a plain
linear mapping. That table needs the LV's real offset inside the physical
volume, which is why the extent map is read back from LVM here rather
than assumed from the creation order.
"""

import atexit
import logging
import os
import subprocess
import time

from pasha.log import complete_step, die

LOG = logging.getLogger(__name__)

SECTOR_SIZE = 512

# Report sizes in bytes with no unit suffix so the values parse as plain
# integers.
_LVM_QUIET = ["--noheadings", "--units", "b", "--nosuffix"]

# The image build runs in a container with no udev daemon, so LVM would wait
# forever for udev to create the device nodes and then fail with "device not
# cleared". Turning the udev integration off makes libdevmapper create
# /dev/mapper/* and /dev/<vg>/* itself, which is what we need here.
_LVM_CONFIG = [
    "--config",
    "activation { udev_sync = 0 udev_rules = 0 verify_udev_operations = 0 }",
]

# Commands that create or change device-mapper devices, and so need the
# settings above. Reporting commands (pvs/vgs/lvs) touch no nodes.
_MUTATING = frozenset(
    ("pvcreate", "vgcreate", "lvcreate", "lvchange", "vgchange", "vgremove",
     "pvremove", "lvremove", "pvresize", "lvextend")
)


def _run(cmd, msg):
    """Run an LVM command, terminating the build on failure."""
    cmd = list(cmd)
    if cmd[0] in _MUTATING:
        cmd[1:1] = _LVM_CONFIG
    LOG.debug("Running %s", " ".join(str(c) for c in cmd))
    try:
        proc = subprocess.run(
            [str(c) for c in cmd], capture_output=True, check=True, text=True
        )
    except FileNotFoundError:
        die(
            f"{cmd[0]} is not installed.",
            hint="As root run 'apt-get install -y lvm2' to install the LVM tools.",
        )
    except subprocess.CalledProcessError as e:
        die(f"{msg}: " + (e.stderr or "").strip())
    return proc.stdout.strip()


def _report(cmd):
    """Run an LVM reporting command and return its stripped rows."""
    out = _run(cmd, f"Failed to run {cmd[0]}")
    return [line.strip() for line in out.splitlines() if line.strip()]


def vg_exists(vg):
    """Return True when the volume group is already known to LVM."""
    proc = subprocess.run(
        ["vgs", "--noheadings", "-o", "vg_name", vg],
        capture_output=True,
        text=True,
    )
    return proc.returncode == 0 and vg in proc.stdout


def deactivate(vg):
    """Deactivate a volume group.

    The logical volumes hold the loop device open, so this has to happen
    before the image is detached or 'losetup -d' fails with EBUSY.
    Best effort: a build that already tore the group down must not fail
    here.
    """
    if not vg_exists(vg):
        return
    LOG.debug(f"Deactivating volume group {vg}.")
    subprocess.run(["vgchange", *_LVM_CONFIG, "-an", vg],
        capture_output=True, text=True)


def remove(vg, device=None):
    """Remove a volume group and, optionally, its physical volume label.

    Used to clear a group left behind by an interrupted build before the
    image is repartitioned; a stale group on a recycled loop device would
    otherwise make vgcreate fail.
    """
    if vg_exists(vg):
        LOG.debug(f"Removing stale volume group {vg}.")
        subprocess.run(["vgchange", *_LVM_CONFIG, "-an", vg],
        capture_output=True, text=True)
        subprocess.run(["vgremove", *_LVM_CONFIG, "-f", vg],
            capture_output=True, text=True)
    if device and os.path.exists(device):
        subprocess.run(["pvremove", *_LVM_CONFIG, "-ff", "-y", device],
            capture_output=True, text=True)


def create_pv(device):
    """Label a block device as an LVM physical volume."""
    if not os.path.exists(device):
        die(f"{device} does not exist.")
    _run(
        ["pvcreate", "-ff", "-y", device],
        f"Failed to create physical volume {device}",
    )


def create_vg(vg, device, extent_size=None):
    """Create a volume group spanning a single physical volume."""
    cmd = ["vgcreate", "-y"]
    if extent_size:
        cmd += ["--physicalextentsize", extent_size]
    cmd += [vg, device]
    _run(cmd, f"Failed to create volume group {vg}")


def create_lv(vg, name, size=None, extents=None, contiguous=True):
    """Create one logical volume in a volume group.

    :param size: LVM size string passed to --size (e.g. "5120M").
    :param extents: LVM extent string passed to --extents (e.g. "100%FREE").
    :param contiguous: allocate a single segment, so the volume can be
                       described by one linear dm-init target.
    """
    if bool(size) == bool(extents):
        die(f"Logical volume {name} needs exactly one of 'size' or 'extents'.")

    # No signature wiping and no zeroing: both open the new volume while
    # lvcreate is still setting it up, which is the fragile moment in a
    # container without udev. There is nothing to wipe anyway -- the image
    # file is freshly truncated, so every extent starts out zeroed -- and the
    # file systems are laid down by the caller straight afterwards.
    cmd = ["lvcreate", "-y", "-Wn", "--zero", "n"]
    if contiguous:
        cmd += ["--alloc", "contiguous"]
    if size:
        cmd += ["--size", size]
    else:
        cmd += ["--extents", extents]
    cmd += ["--name", name, vg]
    _run(cmd, f"Failed to create logical volume {vg}/{name}")


def lv_path(vg, name):
    """Device-mapper path of a logical volume."""
    return f"/dev/{vg}/{name}"


def wait_for_lv(vg, name, timeout_sec=30):
    """Block until a logical volume's device node exists.

    With udev switched off libdevmapper creates the nodes synchronously, but
    waiting keeps the failure legible if that ever stops being true: a clear
    timeout beats mkfs reporting that the device is missing.
    """
    path = lv_path(vg, name)
    deadline = time.monotonic() + timeout_sec
    while not os.path.exists(path):
        if time.monotonic() > deadline:
            die(f"Timed out waiting for {path} to appear.")
        time.sleep(0.2)
    return path


def set_activation_skip(vg, name, skip=True):
    """Set or clear a logical volume's activation-skip flag.

    The rootfs slots are mapped by the kernel through dm-init, before any
    LVM userspace runs. Once the system is up, LVM's event-based
    autoactivation would happily activate the very same volume a second
    time, leaving two device-mapper devices over one set of extents with
    one of them mounted read-write. Flagging the rootfs volumes to be
    skipped stops that; 'data', which nothing else maps, stays
    autoactivated so it can be mounted from fstab.

    Skipped volumes are still activatable on demand with 'lvchange -ay -K',
    which is what an update engine does before writing the inactive slot.
    """
    flag = "y" if skip else "n"
    _run(
        ["lvchange", "--setactivationskip", flag, f"{vg}/{name}"],
        f"Failed to set the activation skip flag on {vg}/{name}",
    )


def _pe_start_sectors(device):
    """First usable sector of the physical volume's data area."""
    rows = _report(["pvs"] + _LVM_QUIET + ["-o", "pe_start", device])
    if not rows:
        die(f"Could not read the physical extent start of {device}.")
    return int(float(rows[0])) // SECTOR_SIZE


def _extent_size_sectors(vg):
    """Physical extent size of the volume group, in sectors."""
    rows = _report(["vgs"] + _LVM_QUIET + ["-o", "vg_extent_size", vg])
    if not rows:
        die(f"Could not read the extent size of volume group {vg}.")
    return int(float(rows[0])) // SECTOR_SIZE


def extent_map(vg, device):
    """Map every logical volume in a group to its offset inside the PV.

    Returns {lv_name: {"start": <sector>, "sectors": <count>}} where both
    values are relative to the start of ``device`` -- exactly the units a
    linear dm target wants. Offsets are identical on the flashed board
    because the physical volume is the same partition image there.

    Volumes made of more than one segment are rejected: a multi-segment
    volume cannot be expressed as the single linear target that dm-init
    consumes, and silently emitting only the first segment would produce
    a rootfs that is truncated rather than obviously broken.
    """
    pe_start = _pe_start_sectors(device)
    extent = _extent_size_sectors(vg)

    segments = {}
    for row in _report(
        ["lvs"] + _LVM_QUIET + ["-o", "lv_name,seg_pe_ranges", "--segments", vg]
    ):
        fields = row.split()
        if len(fields) < 2:
            continue
        name, pe_range = fields[0], fields[1]
        segments.setdefault(name, []).append(pe_range)

    volumes = {}
    for name, ranges in segments.items():
        if len(ranges) != 1:
            die(
                f"Logical volume {vg}/{name} spans {len(ranges)} segments.",
                hint="Create it with --alloc contiguous so it maps to one "
                "linear dm-init target.",
            )
        # seg_pe_ranges looks like "/dev/loop14p2:0-1279".
        pv, _, pe_range = ranges[0].rpartition(":")
        if pv != device:
            die(f"Logical volume {vg}/{name} lives on {pv}, expected {device}.")
        first, _, last = pe_range.partition("-")
        first, last = int(first), int(last or first)
        volumes[name] = {
            "start": pe_start + first * extent,
            "sectors": (last - first + 1) * extent,
        }
    return volumes


def dm_table(name, start, sectors, device, readonly=False):
    """Build one dm-init (dm-mod.create=) entry for a linear volume.

    Format is <name>,<uuid>,<minor>,<flags>,<target...>; uuid and minor
    are left empty so the kernel assigns them.
    """
    flags = "ro" if readonly else "rw"
    return f"{name},,,{flags},0 {sectors} linear {device} {start}"


def register_cleanup(vg):
    """Deactivate the group at interpreter exit.

    atexit handlers run last-in-first-out and pasha registers the loop
    device detach when it resolves ${loopdev:}, i.e. long before this --
    so this runs first and the detach still succeeds on a failed build.
    """
    atexit.register(deactivate, vg)


def create(vg, device, volumes, extent_size=None):
    """Provision a volume group and its logical volumes on one partition.

    :param volumes: list of dicts with 'name' and either 'size' or
                    'extents'. Order matters: volumes are allocated in
                    sequence, so put the volume that should absorb the
                    remaining space (100%FREE) last.
    """
    with complete_step(f"Creating volume group {vg} on {device}"):
        remove(vg, device)
        create_pv(device)
        create_vg(vg, device, extent_size)
        register_cleanup(vg)

        for volume in volumes:
            name = volume.get("name")
            if not name:
                die("Logical volume name is not specified.")
            logging.info(f"Creating logical volume {vg}/{name}")
            create_lv(
                vg,
                name,
                size=volume.get("size"),
                extents=volume.get("extents"),
                contiguous=volume.get("contiguous", True),
            )
