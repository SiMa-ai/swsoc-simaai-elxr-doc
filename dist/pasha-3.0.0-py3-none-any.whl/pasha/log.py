"""
Copyright (c) 2024-2025 Wind River Systems, Inc.

SPDX-License-Identifier: Apache-2.0
"""

import contextlib
import logging
import sys


@contextlib.contextmanager
def complete_step(text, text2=None):
    """Pass a message to the user when a step is happening and
    when it ends.
    """
    print_step(text + "...")
    args = []
    yield args
    if text2 is None:
        text2 = text + " complete"
    # Only format when the step actually yielded results to interpolate.
    # Step texts routinely embed shell commands, and unconditional
    # str.format() turns any literal "{" in them - a brace group, an awk
    # script - into a KeyError that fails the whole stage after its
    # command already ran (SOCSW-6055 PR check, elxr-builder #1569).
    if args:
        text2 = text2.format(*args)
    print_step(text2 + ".")


def print_step(text):
    """Display some text to the logging subsystem."""
    logging.info(f"{text}")


def die(msg, hint=None):
    """Print a message to the user and terminate.
    Hint to the user why rucksack/pasha is being terminated
    """
    logging.error(msg)
    if hint:
        logging.info(hint)
    sys.exit(1)
